package com.google.gwt.playground.client.users;

import com.google.gwt.core.client.GWT;
import com.google.gwt.core.client.RunAsyncCallback;
import com.google.gwt.playground.client.mvp.ActivityMapper;
import com.google.inject.Inject;
import com.google.inject.Provider;

public class UserActivities implements ActivityMapper<UserPlace> {

    private Provider<UserActivity> users;

    @Inject
    UserActivities(Provider<UserActivity> users) {
        this.users = users;
    }

    @Override
    public void getActivity(UserPlace place, final Callback callback) {

        GWT.runAsync(new RunAsyncCallback() {

            @Override
            public void onFailure(Throwable reason) {
                callback.onActivityError(reason);
            }

            @Override
            public void onSuccess() {
                callback.onActivityReady(UserActivities.this.users.get());
            }
        });

    }

}
