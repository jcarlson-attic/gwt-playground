package com.google.gwt.playground.client.mvp;

public interface Display {

    void showActivityWidget(IsWidget widget);

}
