package com.google.gwt.playground.client.users;

import com.google.gwt.playground.client.mvp.IsWidget;
import com.google.gwt.user.client.ui.Composite;
import com.google.gwt.user.client.ui.Label;
import com.google.gwt.user.client.ui.Widget;

public class UserView extends Composite implements IsWidget {

    @Override
    public Widget asWidget() {
        return new Label("Users View!");
    }

}
