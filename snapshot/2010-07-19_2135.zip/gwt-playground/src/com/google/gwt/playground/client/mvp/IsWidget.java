package com.google.gwt.playground.client.mvp;

import com.google.gwt.user.client.ui.Widget;

public interface IsWidget {

    Widget asWidget();

}
