package com.google.gwt.playground.client.users;

import com.google.gwt.playground.client.mvp.Activity;
import com.google.gwt.playground.client.mvp.Display;
import com.google.inject.Inject;

public class UserActivity implements Activity {

    private UserView view;

    @Inject
    UserActivity(UserView view) {
        this.view = view;
    }

    @Override
    public void onCancel() {

    }

    @Override
    public String mayStop() {
        return null;
    }

    @Override
    public void start(Display display) {
        display.showActivityWidget(this.view);
    }

    @Override
    public void onStop() {

    }

}
