package com.google.gwt.playground.client.mvp;

public interface ActivityMapper<P extends Place> {

    interface Callback {

        void onActivityError(Throwable error);

        void onActivityReady(Activity activity);

    }

    void getActivity(P place, Callback callback);

}
